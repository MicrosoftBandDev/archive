﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel.Background;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Microsoft.Band;
using Microsoft.Band.Tiles;
using Microsoft.Band.Tiles.Pages;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace JokeMachine
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private Guid TileId => new Guid(JokeConstants.TileId);
        private Guid PageId => new Guid(JokeConstants.PageId);

        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            await RegisterBackgroundTask(typeof(JokeMachine.Background.Jokes).FullName, "Jokes", new TimeTrigger(15, false), null);

            await SetupBandTile();
        }

        public static async Task<IBackgroundTaskRegistration> RegisterBackgroundTask(string taskEntryPoint,
                                                                      string taskName,
                                                                      IBackgroundTrigger trigger,
                                                                      IBackgroundCondition condition)
        {
            var status = await BackgroundExecutionManager.RequestAccessAsync();
            if (status == BackgroundAccessStatus.Denied || status == BackgroundAccessStatus.Unspecified) return null;

            var current = (from t in BackgroundTaskRegistration.AllTasks
                           where t.Value.Name == taskName
                           select t.Value).FirstOrDefault();
            if (current != null) return current;

            var builder = new BackgroundTaskBuilder
            {
                Name = taskName,
                TaskEntryPoint = taskEntryPoint
            };
            builder.SetTrigger(trigger);

            if (condition != null)
            {
                builder.AddCondition(condition);
            }

            return builder.Register();
        }




        public async Task SetupBandTile()
        {
            var pairedBands = await BandClientManager.Instance.GetBandsAsync();
            using (var client = await BandClientManager.Instance.ConnectAsync(pairedBands[0]))
            {
                var existing = await client.TileManager.GetTilesAsync();
                var myTile = existing.FirstOrDefault(x => x.TileId == TileId);
                if (myTile == null && await client.TileManager.GetRemainingTileCapacityAsync() > 0)
                {

                    var designed = new JokeStartStopTile();
                    myTile = new BandTile(TileId)
                    {
                        Name = "Jokes",
                        TileIcon = await LoadIcon("ms-appx:///Assets/LargeIcon.png"),
                        SmallIcon = await LoadIcon("ms-appx:///Assets/SmallIcon.png")
                    };
                    myTile.PageLayouts.Add(designed.Layout);

                    await designed.LoadIconsAsync(myTile);

                    await client.TileManager.AddTileAsync(myTile);

                    await client.TileManager.SetPagesAsync(TileId, new PageData(PageId, 0, designed.Data.All));

                }

            // Subscribe to background tile events
            await client.SubscribeToBackgroundTileEventsAsync(TileId);
            }
        }

        private async Task<BandIcon> LoadIcon(string uri)
        {
            StorageFile imageFile = await StorageFile.GetFileFromApplicationUriAsync(new Uri(uri));

            using (IRandomAccessStream fileStream = await imageFile.OpenAsync(FileAccessMode.Read))
            {
                WriteableBitmap bitmap = new WriteableBitmap(1, 1);
                await bitmap.SetSourceAsync(fileStream);
                return bitmap.ToBandIcon();
            }
        }

    }
}

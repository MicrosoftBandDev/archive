﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.AppService;
using Windows.ApplicationModel.Background;
using Windows.Foundation.Collections;
using Windows.Storage;
using Microsoft.Band;
using Microsoft.Band.Notifications;
using Microsoft.Band.Tiles;
using Microsoft.Band.Tiles.Pages;

namespace JokeMachine.Background
{
    public sealed class Jokes : IBackgroundTask
    {
        private Guid TileId => new Guid(JokeConstants.TileId);
        private Guid PageId => new Guid(JokeConstants.PageId);
        private const string JokeIndexKey = "Index";
        private const string IsRunningKey = "Running";
        
        private static IBandClient BandClient { get; set; }
        private BackgroundTaskDeferral BackgroundTaskDeferral { get; set; }

        private AppServiceConnection AppServiceconnection { get; set; }

        private bool IsRunning => (bool)(ApplicationData.Current.LocalSettings.Values[IsRunningKey] ?? false);
        
        public void Run(IBackgroundTaskInstance taskInstance)
        {
            BackgroundTaskDeferral = taskInstance.GetDeferral();

            // Associate a cancellation handler with the background task.
            taskInstance.Canceled += OnTaskCanceled;

            // Add our handlers for tile events
            BackgroundTileEventHandler.Instance.TileOpened += EventHandler_TileOpened;
            BackgroundTileEventHandler.Instance.TileClosed += EventHandler_TileClosed;
            BackgroundTileEventHandler.Instance.TileButtonPressed += EventHandler_TileButtonPressed;

            // Retrieve the app service connection and set up a listener for incoming app service requests.
            var details = taskInstance.TriggerDetails as AppServiceTriggerDetails;
            if (details != null)
            {
                AppServiceconnection = details.AppServiceConnection;
                AppServiceconnection.RequestReceived += OnRequestReceived;
            }
            else
            {

                TellAJoke();
            }

        }


        private async void OnRequestReceived(AppServiceConnection sender, AppServiceRequestReceivedEventArgs args)
        {
            // Get a deferral because we use an awaitable API below to respond to the message
            // and we don't want this call to get cancelled while we are waiting.
            var messageDeferral = args.GetDeferral();

            var responseMessage = new ValueSet();

            // Decode the received message and call the appropriate event handler
            BackgroundTileEventHandler.Instance.HandleTileEvent(args.Request.Message);

            // Send the response message
            await args.Request.SendResponseAsync(responseMessage);

            // Complete the deferral so that the platform knows that we're done responding
            messageDeferral.Complete();
        }

        private void EventHandler_TileOpened(object sender, BandTileEventArgs<IBandTileOpenedEvent> e)
        {
            UpdatePageData($"Welcome to the Joke Machine {IsRunning}");
        }

        /// <summary>
        /// Handle the event that occurs when our tile is closed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">Data describing the event details</param>
        private void EventHandler_TileClosed(object sender, BandTileEventArgs<IBandTileClosedEvent> e)
        {
            DisconnectBand();
        }



        /// <summary>
        /// Handle the event that occurs when the user presses a button on page of the tile
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">Data describing the event details</param>
        private void EventHandler_TileButtonPressed(object sender, BandTileEventArgs<IBandTileButtonPressedEvent> e)
        {
            var running = e?.TileEvent?.ElementId == 2;
            ApplicationData.Current.LocalSettings.Values[IsRunningKey] = running;

            UpdatePageData(running ? "Joke Machine is Running!" : "Joke Machine Stopped");
        }

        /// <summary>
        /// Update the page of data displayed within our tile
        /// </summary>
        private void UpdatePageData(string status)
        {
            ConnectBand();

            var designed = new JokeStartStopTile();
            designed.Data.BeginModify();

            designed.txtStatusData.Text = status;

            BandClient.TileManager.SetPagesAsync(TileId,
                new PageData(PageId, 0, designed.Data.All)).Wait();
        }


        private void TellAJoke()
        {

            // Select the joke to tell
            var index = (int)(ApplicationData.Current.LocalSettings.Values[JokeIndexKey] ?? 0) % JokeConstants.Jokes.Length;
            var joke = JokeConstants.Jokes[index++];
            ApplicationData.Current.LocalSettings.Values[JokeIndexKey] = index;
            
            ConnectBand(false);

            // Remove previous jokes
            BandClient.TileManager.RemovePagesAsync(TileId);

            // Send a joke.
            BandClient.NotificationManager.SendMessageAsync(TileId, JokeConstants.JokeTitle, joke, DateTimeOffset.Now, MessageFlags.ShowDialog).Wait();

            CompleteTask();
        }

        private void ConnectBand(bool inBackground = true)
        {
            if (BandClient == null)
            {
                var pairedBands = BandClientManager.Instance.GetBandsAsync(inBackground).Result;
                if (pairedBands?.Length > 0)
                {
                    BandClient = BandClientManager.Instance.ConnectAsync(pairedBands[0]).Result;
                }
            }
        }


        private void OnTaskCanceled(IBackgroundTaskInstance sender, BackgroundTaskCancellationReason reason)
        {
            CompleteTask();
        }

        private void CompleteTask()
        {
            DisconnectBand();

            // Complete the service deferral.
            BackgroundTaskDeferral?.Complete();
        }

        private void DisconnectBand()
        {
            BandClient?.Dispose();
            BandClient = null;
        }
    }

}

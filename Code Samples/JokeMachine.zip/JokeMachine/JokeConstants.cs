namespace JokeMachine
{
    public static class JokeConstants
    {
        public static string TileId { get; } = "962A2F11-38F7-4091-AD13-76CE151FF442";
        public static string PageId { get; } = "65432F5E-3E9B-4711-998E-BB868660B325";

        public static string JokeTitle { get; } = "Band Joke";

        public static string[] Jokes { get; } = {
            "There was once a trumpet player who practiced 5 hours daily and was very conceited. He liked to toot his horn",
            "what do you call 50000 piccolos at the bottom of the sea? A good start.",
            "What do you call a euphonist that isn't in a military band? Unemployed.",
            "Johnny told his mom he wanted to play trumpet when he grew up. His mom said: \"Honey, you can't do both, pick one.\"",
            "How do you stop a guitarist? Sheet music."
        };
    }
}
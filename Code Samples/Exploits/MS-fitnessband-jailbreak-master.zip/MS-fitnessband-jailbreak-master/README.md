# MS-fitnessband-jailbreak
simple scripts to parse and patch Microsoft fitness band firmware update file 
[Blog post](https://www.b0n0n.com/2016/04/jailbreaking-microsoft-fitness-band_20.html)

//----------------------------------------------------------------
//
//  Copyright (c) Microsoft Corporation. All rights reserved.
//
//----------------------------------------------------------------

#import <Foundation/Foundation.h>
#import "MSBPageElement.h"

@interface MSBPageElementData : NSObject

@property (nonatomic, readonly) MSBPageElementIdentifier   elementId;

@end

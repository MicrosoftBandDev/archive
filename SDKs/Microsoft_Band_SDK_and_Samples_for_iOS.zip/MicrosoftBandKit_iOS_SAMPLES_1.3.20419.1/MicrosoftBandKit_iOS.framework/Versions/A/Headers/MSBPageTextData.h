//----------------------------------------------------------------
//
//  Copyright (c) Microsoft Corporation. All rights reserved.
//
//----------------------------------------------------------------

#import "MSBPageElementData.h"

@interface MSBPageTextData : MSBPageElementData

@property (nonatomic, readonly) NSString  *text;

@end
